#ifndef BUYER_NEWPURCHASE_H
#define BUYER_NEWPURCHASE_H

#include <QDialog>
#include <QStandardItemModel>

namespace Ui {
class Buyer_NewPurchase;
}

class Buyer_NewPurchase : public QDialog
{
    Q_OBJECT

public:
    explicit Buyer_NewPurchase(QWidget *parent = nullptr);
    ~Buyer_NewPurchase();

signals:
    void backToMain();

private slots:
    void on_btn_back_clicked();

    void on_btn_submit_clicked();

    void on_btn_addrow_clicked();

    void on_btn_deleterow_clicked();

private:
    Ui::Buyer_NewPurchase *ui;
    QStandardItemModel *model;
    int currentRowCount;
};

#endif // BUYER_NEWPURCHASE_H
