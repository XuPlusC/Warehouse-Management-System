#include "buyer_newpurchase.h"
#include "ui_buyer_newpurchase.h"
#include <QDebug>
#include <QStandardItem>
#include <QStandardItemModel>
#define MAX_LOG_PER_PURCHASE 5

Buyer_NewPurchase::Buyer_NewPurchase(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Buyer_NewPurchase)
{
    ui->setupUi(this);

    model= new QStandardItemModel();

    /*设置列字段名*/
    model->setColumnCount(2);
    model->setHeaderData(0, Qt::Horizontal, "货品编号");
    model->setHeaderData(1, Qt::Horizontal, "货品数量");

    currentRowCount = 1;
    /*设置行字段名*/
    model->setRowCount(currentRowCount);
    model->setHeaderData(0, Qt::Vertical, "1");
//    model->setHeaderData(1,Qt::Vertical, "2");
//    model->setHeaderData(2,Qt::Vertical, "3");
//    model->setHeaderData(3,Qt::Vertical, "4");
//    model->setHeaderData(4,Qt::Vertical, "5");

    model->setItem(0, 0, new QStandardItem("pen"));
    model->setItem(0, 1, new QStandardItem("200"));
    ui->tableView_display->setModel(model);
}

Buyer_NewPurchase::~Buyer_NewPurchase()
{
    delete ui;
}

void Buyer_NewPurchase::on_btn_back_clicked()
{
    emit(backToMain());
}


void Buyer_NewPurchase::on_btn_submit_clicked()
{
    int status = 1;
    for(int i = 0; i < currentRowCount ; ++i)
    {
        for(int j = 0; j < 2; ++j)
        {
            if(model->item(i, j) == NULL)
            {
                qDebug() << "item (" << i << "," << j << ") is null!";
                QString strout = "check null at (";
                strout += QString(i+'1'); strout += ", "; strout += QString(j+'1'); strout += ")!";
                ui->label_info->setText(strout);
                status = 0;
                break;
            }
        }
        if(!status)
            break;
        qDebug() << "row " << i << ": "
                 << model->item(i, 0)->text() << " "
                 << model->item(i, 1)->text() << ";";
    }
}

void Buyer_NewPurchase::on_btn_addrow_clicked()
{
    model->setRowCount(++currentRowCount);
    model->setHeaderData(currentRowCount-1, Qt::Vertical, QString(currentRowCount-1+'1'));
}

void Buyer_NewPurchase::on_btn_deleterow_clicked()
{
    if(currentRowCount > 0)
    {
        currentRowCount--;
        model->removeRow(ui->tableView_display->currentIndex().row());
        for(int i = 0; i < currentRowCount; ++i)
        {
            model->setHeaderData(i, Qt::Vertical, QString('1'+i));
        }
    }
}
